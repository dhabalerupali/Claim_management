package com.project.web.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class claim {

	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private int claimId;
	private String claimname;
	private int claimnumber;
	private String claimdiscription;
	private String claimDate;
	private String claimstatus;
	public int getClaimId() {
		return claimId;
	}
	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}
	public String getClaimname() {
		return claimname;
	}
	public void setClaimname(String claimname) {
		this.claimname = claimname;
	}
	public int getClaimnumber() {
		return claimnumber;
	}
	public void setClaimnumber(int claimnumber) {
		this.claimnumber = claimnumber;
	}
	public String getClaimdiscription() {
		return claimdiscription;
	}
	public void setClaimdiscription(String claimdiscription) {
		this.claimdiscription = claimdiscription;
	}
	public String getClaimDate() {
		return claimDate;
	}
	public void setClaimDate(String claimDate) {
		this.claimDate = claimDate;
	}
	public String getClaimstatus() {
		return claimstatus;
	}
	public claim() {
		super();
		// TODO Auto-generated constructor stub
	}
	public claim(int claimId, String claimname, int claimnumber, String claimdiscription, String claimDate,
			String claimstatus) {
		super();
		this.claimId = claimId;
		this.claimname = claimname;
		this.claimnumber = claimnumber;
		this.claimdiscription = claimdiscription;
		this.claimDate = claimDate;
		this.claimstatus = claimstatus;
	}
	public void setClaimstatus(String claimstatus) {
		this.claimstatus = claimstatus;
	}
	@Override
	public String toString() {
		return "claim [claimId=" + claimId + ", claimname=" + claimname + ", claimnumber=" + claimnumber
				+ ", claimdiscription=" + claimdiscription + ", claimDate=" + claimDate + ", claimstatus=" + claimstatus
				+ "]";
	}
	
	
}
