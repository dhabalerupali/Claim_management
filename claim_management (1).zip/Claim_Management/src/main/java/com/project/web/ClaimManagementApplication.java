package com.project.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaimManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaimManagementApplication.class, args);
		System.out.println("Running");
	}

}
