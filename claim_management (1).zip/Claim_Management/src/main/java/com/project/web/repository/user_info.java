package com.project.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.web.model.user;

public interface user_info extends JpaRepository<user,Integer>{

	public user findByEmail(String email);

}
