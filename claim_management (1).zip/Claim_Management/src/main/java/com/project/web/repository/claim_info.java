package com.project.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.web.model.claim;

public interface claim_info extends JpaRepository<claim,Integer>{
	

}
