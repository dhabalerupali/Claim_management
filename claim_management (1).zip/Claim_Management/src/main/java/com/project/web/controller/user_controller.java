package com.project.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.project.web.model.user;
import com.project.web.repository.claim_info;
import com.project.web.repository.user_info;

@Controller
public class user_controller {
	
	
	@Autowired
	private user_info emprepo;
	@GetMapping("/")
	public String home()
	{
		return "Register.jsp";
	}
	
	@PostMapping("/register")
	public String register(@ModelAttribute user ee)
	{
		emprepo.save(ee);
		return "Login.jsp";
	}
	
	

	@PostMapping("/login")
	public String login(@RequestParam String email,@RequestParam String password)
	{
		user ob=emprepo.findByEmail(email);
		
		if(ob!=null && ob.getEmail().equals(email) && ob.getPassword().equals(password))
		{
			return "redirect:/add";
		}
		else
		{
		return "Login.jsp";
	
	
	}
}
}